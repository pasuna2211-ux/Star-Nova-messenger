// Nova AI - single free proxy for Cloudflare Workers.
//   Any path         -> Google Gemini (works without VPN)
//   POST /image      -> image generation (FLUX) via Cloudflare Workers AI
//   /music/v1/...    -> ACE Music (free AI music API), forwarded as is
//   POST /tavily     -> Tavily web search (so internet mode works even when the browser blocks direct calls)
//   GET  /status     -> health check ("Check proxy" button in the app)
// Your keys are not stored here: the Gemini key just passes through in the request header.
// For images: Worker -> Settings -> Bindings -> Add -> Workers AI, variable name: AI

const GOOGLE = 'https://generativelanguage.googleapis.com';
const ACE = 'https://api.acemusic.ai';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-goog-api-key, x-goog-api-client, x-goog-upload-protocol, x-goog-upload-command, x-goog-upload-header-content-length, x-goog-upload-header-content-type, x-goog-upload-offset',
  'Access-Control-Expose-Headers': 'x-goog-upload-url, x-goog-upload-status, x-goog-upload-chunk-granularity',
  'Access-Control-Max-Age': '86400'
};

const IMAGE_MODELS = {
  'klein-9b': '@cf/black-forest-labs/flux-2-klein-9b',
  'klein-4b': '@cf/black-forest-labs/flux-2-klein-4b',
  'schnell': '@cf/black-forest-labs/flux-1-schnell'
};

function json(obj, status) {
  const h = new Headers(CORS);
  h.set('Content-Type', 'application/json');
  return new Response(JSON.stringify(obj), { status: status || 200, headers: h });
}

function bytesToBase64(bytes) {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
  }
  return btoa(bin);
}

async function toBase64(out) {
  if (!out) return '';
  if (typeof out === 'string') return out;
  if (typeof out.image === 'string') return out.image;
  if (typeof out.getReader === 'function') {
    return bytesToBase64(new Uint8Array(await new Response(out).arrayBuffer()));
  }
  if (out instanceof ArrayBuffer) return bytesToBase64(new Uint8Array(out));
  if (ArrayBuffer.isView(out)) {
    return bytesToBase64(new Uint8Array(out.buffer, out.byteOffset, out.byteLength));
  }
  return '';
}

async function handleImage(request, env) {
  if (!env || !env.AI) {
    return json({ error: 'Workers AI is not bound. Settings > Bindings > Add > Workers AI, variable name: AI' }, 501);
  }
  let body = {};
  try { body = await request.json(); } catch (e) { body = {}; }
  const prompt = String(body.prompt || '').trim().slice(0, 2000);
  if (!prompt) return json({ error: 'Empty prompt' }, 400);

  const key = IMAGE_MODELS[body.model] ? body.model : 'klein-4b';
  const model = IMAGE_MODELS[key];
  // FLUX.2 wants sizes that are multiples of 16
  const clamp = function (v) {
    const n = Math.min(1536, Math.max(256, parseInt(v, 10) || 1024));
    return Math.round(n / 16) * 16;
  };
  const width = clamp(body.width);
  const height = clamp(body.height);

  try {
    let out;
    if (key === 'schnell') {
      out = await env.AI.run(model, { prompt: prompt, steps: 8 });
    } else {
      // FLUX.2 models take multipart/form-data
      const form = new FormData();
      form.append('prompt', prompt);
      form.append('width', String(width));
      form.append('height', String(height));
      if (body.seed) form.append('seed', String(body.seed));
      const packed = new Response(form);
      out = await env.AI.run(model, {
        multipart: { body: packed.body, contentType: packed.headers.get('content-type') }
      });
    }
    const b64 = await toBase64(out);
    if (!b64 || b64.length < 200) return json({ error: 'Model returned an empty image' }, 502);
    return json({ image: b64, model: key });
  } catch (e) {
    const msg = String((e && e.message) || e);
    const quota = /neuron|allocation|4006|quota|rate limit|too many/i.test(msg);
    return json({ error: msg.slice(0, 200), quota: quota }, quota ? 429 : 502);
  }
}

async function handleMusic(request, url) {
  // only the OpenAI-compatible endpoints of ACE Music, nothing else
  const rest = url.pathname.slice('/music'.length);
  if (rest.indexOf('/v1/') !== 0) return json({ error: 'Not found' }, 404);
  const headers = new Headers();
  for (const h of ['content-type', 'accept', 'authorization']) {
    const v = request.headers.get(h);
    if (v) headers.set(h, v);
  }
  const noBody = request.method === 'GET' || request.method === 'HEAD';
  let upstream;
  try {
    upstream = await fetch(ACE + rest + url.search, {
      method: request.method,
      headers: headers,
      body: noBody ? undefined : request.body
    });
  } catch (e) {
    return json({ error: 'Proxy could not reach ACE Music' }, 502);
  }
  const out = new Headers(upstream.headers);
  for (const k of Object.keys(CORS)) out.set(k, CORS[k]);
  return new Response(upstream.body, { status: upstream.status, headers: out });
}

async function handleTavily(request) {
  if (request.method !== 'POST') return json({ error: 'Use POST' }, 405);
  const headers = new Headers();
  headers.set('Content-Type', 'application/json');
  const auth = request.headers.get('authorization');
  if (auth) headers.set('Authorization', auth);
  let upstream;
  try {
    upstream = await fetch('https://api.tavily.com/search', { method: 'POST', headers: headers, body: request.body });
  } catch (e) {
    return json({ error: 'Proxy could not reach Tavily' }, 502);
  }
  const out = new Headers(upstream.headers);
  for (const k of Object.keys(CORS)) out.set(k, CORS[k]);
  return new Response(upstream.body, { status: upstream.status, headers: out });
}

async function handleGemini(request, url) {
  const headers = new Headers();
  const pass = ['content-type', 'accept', 'x-goog-api-key', 'x-goog-api-client',
    'x-goog-upload-protocol', 'x-goog-upload-command', 'x-goog-upload-header-content-length',
    'x-goog-upload-header-content-type', 'x-goog-upload-offset'];
  for (const h of pass) {
    const v = request.headers.get(h);
    if (v) headers.set(h, v);
  }
  const noBody = request.method === 'GET' || request.method === 'HEAD';
  let upstream;
  try {
    upstream = await fetch(GOOGLE + url.pathname + url.search, {
      method: request.method,
      headers: headers,
      body: noBody ? undefined : request.body
    });
  } catch (e) {
    return json({ error: { message: 'Proxy could not reach Google' } }, 502);
  }
  const out = new Headers(upstream.headers);
  for (const k of Object.keys(CORS)) out.set(k, CORS[k]);
  return new Response(upstream.body, { status: upstream.status, headers: out });
}

export default {
  async fetch(request, env) {
    try {
      if (request.method === 'OPTIONS') {
        return new Response(null, { status: 204, headers: CORS });
      }
      const url = new URL(request.url);
      const path = url.pathname.replace(/\/+$/, '') || '/';
      if (path === '/status') {
        return json({ nova: true, ai: !!(env && env.AI), music: true, tavily: true, v: 5 });
      }
      if (path === '/image') {
        if (request.method !== 'POST') return json({ error: 'Use POST' }, 405);
        return await handleImage(request, env);
      }
      if (path === '/tavily') return await handleTavily(request);
      if (path.indexOf('/music/') === 0) return await handleMusic(request, url);
      return await handleGemini(request, url);
    } catch (e) {
      return json({ error: String((e && e.message) || e).slice(0, 200) }, 500);
    }
  }
};
